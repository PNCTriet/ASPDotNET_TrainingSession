﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Online_ticket_platform_DAL.Repositories
{
    internal class DAL_PaymentRepository
    {
    }
}
